# Senior-Project
Pathfinder, maze solving visualizer, my senior project


Just a fun toy to play with, 
add a start and end point, draw a maze, choose a pathfinding algorithm and then run<br>
you can also make the delay between searches longer if you really wanna watch it move<br>
load up some pre-made maps if you don't wanna draw <br>
currently there is no easy way to save a maze you draw, instructions to do so below:
<br><br>
  open the HTML<br>
  inspect > open console<br>
  refresh page to fix grid sizing<br>
  draw the maze you wish to save<br>
  right click on console to clear log <br>
  type: console.log(grid)<br>
  right click on console to save<br>
  save as a .txt in appropriate mazes folder<br>


  
